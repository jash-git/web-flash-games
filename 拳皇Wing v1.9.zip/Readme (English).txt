﻿===============================
【The King Of Fighters Wing 1.9 (Local version)】
===============================
Before you play the game:
1) Please be sure your loader1.9.swf , data, sound , stage are placing in the same directory , also they must not be separated.

2) 
Windows 7/Vista OS:
Open "data" directory and double click to open AMBIENT.TFF and impact.ttf to install one of the font which the game has used.
Windows XP or before:
Copy the AMBIENT.TFF and impact.ttf into C:\Windows\Fonts

Also, please download the following font and install it directly by double click opening.
http://download.microsoft.com/download/c/7/e/c7e5397d-004f-468b-a441-dd0828dc1a17/VistaFont_CHS.EXE
Otherwise the game cannot display some of the font appropriately , e.g. Score board.

3) Since some of the skill has been updated, we hope all of you to notice the change of the skill list. 
For example, ↓←+punch of K' has been changed to  ↓→+kick (only when you jump)

**************************************************************
Detailed update content:
-------------------------------------
1) New character added--Boss , Rugal
2) Most of the effect has became more gorgeous
3) Some bugs have been fixed
4) Life test is aded in trainning mode. (please click "Instruction" button when you are in the fighting scene to know the using method)
5) Reset and music setting function is added in the game. (please click "Instruction" button when you are in the fighting scene to know the using method)
6) Boss have been encrypted (There are two kinds of decrypt method, please check the instruction in "Credit" page of the main menu.)
7) Flow of the game:
    a) The program will randomly choose 5 characters to challenge the player.
    b) After 5 characters, if the character you chose is not Iori, Orochi Iori will have half of              the probability to challenge the player.
    c) If the character you selected is K' or Kula, the boss must be Igniz. Otherwise, Igniz or         Rugal (one of them, one of the type) will challenge the player.
    d) Ultimate Boss--- Orochi (one of the type) will be the last boss.
8) Service is added, after game over , if you select "continue game" , service will appear. Player will have 4 options: 
A. Opponent's life decrease by 1 bar
B. Less consumption of  superskill
C. Decrease Level's Diffucultiy
D. No SERVICE
Explaination: 
(Service will last for one stage only.(Except option C.) )A: The life of opponent will decrease by 1 bar, if you have already set the life to 1 in the setting before the battle , no service will be applied for the game.B: The power consumption of triggering the super skill or max skill will decreased by half.
(If you select D, the score of the game will only decrease by half, otherwise , all score will be set to 0.)

***************************************************************
Tips: The artificial intelligence and the skill strength of Orochi has been strengthened. Master can challenge Orochi Level5 , otherwise, if you do not want to lose, you can just practice from fighting with Level5.
Eventually, hope everyone enjoy this game and thank for your support!
Surf following page to know more about the information of KOFWINGl

Flashwing Studio Website:
http://www.flashwing.net/
The King Of Fighters Wing Page:
http://kof.flashwing.net/
Flashwing Forum (Repairing the website time to time but you can still surf this website.)
http://bbs.flashwing.net/
================================================

Producer
Flashwing Studio---Dreamer0078 , hcw12889 , chenxin0397 ,TY Ling

Assistant team
Flashwing Knight Team , Flashwing Knight trainning camp

@Flashwing Studio 2013